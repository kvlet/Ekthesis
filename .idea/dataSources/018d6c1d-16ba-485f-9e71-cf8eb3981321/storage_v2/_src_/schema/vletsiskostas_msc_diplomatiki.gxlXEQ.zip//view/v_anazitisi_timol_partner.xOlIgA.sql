create definer = mscadmin@`%` view v_anazitisi_timol_partner as
select `t`.`Ar_timologio_partner` AS `ar_timologio_partner`,
       `t`.`Date_timol`           AS `date_timol`,
       `t`.`id_partner`           AS `id_partner`,
       `u`.`L_name`               AS `l_name`,
       `g`.`Name`                 AS `name`
from ((`vletsiskostas_msc_diplomatiki`.`db_pliromes_timologion_partner` `t` join `vletsiskostas_msc_diplomatiki`.`db_grafeio` `g` on (`t`.`id_grafeio` = `g`.`id_grafeio`))
         join `vletsiskostas_msc_diplomatiki`.`db_users` `u` on (`t`.`id_partner` = `u`.`id_users`))
where `t`.`Valid` = 'true';

