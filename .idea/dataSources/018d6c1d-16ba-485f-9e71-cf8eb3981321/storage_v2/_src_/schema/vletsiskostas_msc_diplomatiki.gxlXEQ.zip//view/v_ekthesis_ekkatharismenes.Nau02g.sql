create definer = mscadmin@`%` view v_ekthesis_ekkatharismenes as
select `e`.`id_ekthesis`          AS `id_ekthesis`,
       `e`.`Date_atiximatos`      AS `date_atiximatos`,
       `p`.`L_name`               AS `L_name`,
       `c`.`comp_name`            AS `comp_name`,
       `o`.`Ar_kyklo`             AS `ar_kyklo`,
       `e`.`id_grafeio`           AS `id_grafeio`,
       `e`.`Ar_timologio_partner` AS `Ar_timologio_partner`,
       `e`.`id_users`             AS `id_users`
from (((`vletsiskostas_msc_diplomatiki`.`db_ekthesis` `e` join `vletsiskostas_msc_diplomatiki`.`db_person` `p` on (`e`.`id_pathon` = `p`.`id_person`)) join `vletsiskostas_msc_diplomatiki`.`db_company` `c` on (`e`.`id_company_pathon` = `c`.`id_company`))
         join `vletsiskostas_msc_diplomatiki`.`db_oximata` `o` on (`e`.`id_oximatos_pathon` = `o`.`id_oximata`))
where `e`.`Valid` = 'true'
  and `e`.`Ekkatharistike` = 'Íáé';

