create definer = mscadmin@`%` view v_ekthesis_for_billing as
select `e`.`id_ekthesis`            AS `id_ekthesis`,
       `e`.`Date_atiximatos`        AS `date_atiximatos`,
       `p`.`L_name`                 AS `L_name`,
       `c`.`comp_name`              AS `comp_name`,
       `o`.`Ar_kyklo`               AS `ar_kyklo`,
       `e`.`id_company_pathon`      AS `id_company_pathon`,
       `e`.`id_grafeio`             AS `id_grafeio`,
       `e`.`id_timologio_etaireias` AS `id_timologio_etaireias`,
       `s`.`id_status`              AS `id_status`
from ((((`vletsiskostas_msc_diplomatiki`.`db_ekthesis` `e` join `vletsiskostas_msc_diplomatiki`.`db_person` `p` on (`e`.`id_pathon` = `p`.`id_person`)) join `vletsiskostas_msc_diplomatiki`.`db_company` `c` on (`e`.`id_company_pathon` = `c`.`id_company`)) join `vletsiskostas_msc_diplomatiki`.`db_status_ekthesis` `s` on (`e`.`id_ekthesis` = `s`.`id_ekthesis`))
         join `vletsiskostas_msc_diplomatiki`.`db_oximata` `o` on (`e`.`id_oximatos_pathon` = `o`.`id_oximata`))
where `e`.`Valid` = 'true'
  and (`s`.`id_status` = 5 or `s`.`id_status` = 6)
  and `s`.`Valid` = 'Íáé';

