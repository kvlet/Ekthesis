create definer = mscadmin@`%` view v_ekthesis_of_prot_bibliou as
select `e`.`id_ekthesis`     AS `id_ekthesis`,
       `e`.`Date_atiximatos` AS `date_atiximatos`,
       `p`.`L_name`          AS `L_name`,
       `p`.`F_name`          AS `F_name`,
       `c`.`comp_name`       AS `comp_name`,
       `e`.`Prot_bibliou`    AS `prot_bibliou`,
       `e`.`id_users`        AS `id_users`
from ((`vletsiskostas_msc_diplomatiki`.`db_ekthesis` `e` join `vletsiskostas_msc_diplomatiki`.`db_person` `p` on (`e`.`id_pathon` = `p`.`id_person`))
         join `vletsiskostas_msc_diplomatiki`.`db_company` `c` on (`e`.`id_company_pathon` = `c`.`id_company`))
where `e`.`Valid` = 'true';

