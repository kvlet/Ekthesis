create definer = mscadmin@`%` view v_timol_for_pay as
select `t`.`id_timologio`  AS `id_timologio`,
       `t`.`Ar_timologiou` AS `ar_timologiou`,
       `t`.`Date_ekdosis`  AS `date_ekdosis`,
       `t`.`id_company`    AS `id_company`,
       `t`.`id_grafeio`    AS `id_grafeio`,
       `t`.`Ypoloipo`      AS `ypoloipo`,
       `c`.`comp_name`     AS `comp_name`,
       `g`.`Name`          AS `name`
from ((`vletsiskostas_msc_diplomatiki`.`db_timologio_etaireias` `t` join `vletsiskostas_msc_diplomatiki`.`db_company` `c` on (`t`.`id_company` = `c`.`id_company`))
         join `vletsiskostas_msc_diplomatiki`.`db_grafeio` `g` on (`t`.`id_grafeio` = `g`.`id_grafeio`))
where `t`.`Valid` = 'Íáé'
  and `t`.`Ypoloipo` > 0;

-- comment on column v_timol_for_pay.ypoloipo not supported: Υπολογίζεται απο το άθροισμα του merikos_pliroteo+eksoda_timologion την πρώτη φορά και αυτό το άθροισμα πάει και το υπόλοιπο της εταιρείας. μετά αφαιρείται απο αυτό κάθε φορά το ποσό της πληρωμής.

