create definer = mscadmin@`%` view v_anazitisi_timol as
select `t`.`id_timologio`  AS `id_timologio`,
       `t`.`Ar_timologiou` AS `ar_timologiou`,
       `t`.`Date_ekdosis`  AS `date_ekdosis`,
       `t`.`Valid`         AS `valid`,
       `c`.`comp_name`     AS `comp_name`,
       `g`.`Name`          AS `name`
from ((`vletsiskostas_msc_diplomatiki`.`db_timologio_etaireias` `t` join `vletsiskostas_msc_diplomatiki`.`db_company` `c` on (`t`.`id_company` = `c`.`id_company`))
         join `vletsiskostas_msc_diplomatiki`.`db_grafeio` `g` on (`t`.`id_grafeio` = `g`.`id_grafeio`))
where `t`.`Valid` = 'Íáé';

