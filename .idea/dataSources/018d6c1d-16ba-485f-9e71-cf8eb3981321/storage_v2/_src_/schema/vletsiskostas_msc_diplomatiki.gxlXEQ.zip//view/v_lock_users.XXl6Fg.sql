create definer = mscadmin@`%` view v_lock_users as
select `u`.`id_users` AS `id_users`, `u`.`user_name` AS `user_name`, `u`.`F_name` AS `F_name`, `u`.`L_name` AS `l_name`
from (`vletsiskostas_msc_diplomatiki`.`db_users` `u`
         join `vletsiskostas_msc_diplomatiki`.`db_users_online` `uon` on (`u`.`id_users` = `uon`.`id_users_online`))
where `u`.`Active` = 'Íáé';

