create definer = mscadmin@`%` view v_value_expen_9 as
select `e`.`id_ekthesis`  AS `id_ekthesis`,
       `ex`.`id_expenses` AS `id_expenses`,
       `ex`.`Value`       AS `value`,
       `ex`.`Quan`        AS `quan`
from (`vletsiskostas_msc_diplomatiki`.`db_ekthesis` `e`
         join `vletsiskostas_msc_diplomatiki`.`db_expen_ekthesis` `ex` on (`e`.`id_ekthesis` = `ex`.`id_ekthesis`))
where `ex`.`id_expenses` = 9;

-- comment on column v_value_expen_9.value not supported: Για όλα τα έξοδα περναμε την αξία χωρίς Φ.Π.Α.  Εκτός απο τα εξοδα βαση τιμολογιων(id_expenses=9)

