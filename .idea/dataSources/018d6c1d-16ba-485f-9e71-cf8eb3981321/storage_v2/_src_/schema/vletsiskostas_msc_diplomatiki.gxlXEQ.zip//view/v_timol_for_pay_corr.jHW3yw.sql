create definer = mscadmin@`%` view v_timol_for_pay_corr as
select `t`.`id_timologio`   AS `id_timologio`,
       `te`.`Ar_timologiou` AS `ar_timologiou`,
       `t`.`Date_pliromis`  AS `date_pliromis`,
       `t`.`id_grafeio`     AS `id_grafeio`,
       `t`.`Value`          AS `value`,
       `g`.`Name`           AS `name`
from ((`vletsiskostas_msc_diplomatiki`.`db_pliromes_timologion_etaireias` `t` join `vletsiskostas_msc_diplomatiki`.`db_timologio_etaireias` `te` on (`t`.`id_timologio` = `te`.`id_timologio`))
         join `vletsiskostas_msc_diplomatiki`.`db_grafeio` `g` on (`t`.`id_grafeio` = `g`.`id_grafeio`));

