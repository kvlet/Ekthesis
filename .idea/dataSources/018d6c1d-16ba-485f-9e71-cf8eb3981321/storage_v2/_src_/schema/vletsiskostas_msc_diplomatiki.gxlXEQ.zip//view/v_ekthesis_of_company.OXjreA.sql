create definer = mscadmin@`%` view v_ekthesis_of_company as
select `e`.`id_ekthesis`       AS `id_ekthesis`,
       `e`.`Date_eksetasis`    AS `date_eksetasis`,
       `a`.`Place`             AS `place`,
       `o`.`Ar_kyklo`          AS `ar_kyklo`,
       `m`.`marka`             AS `marka`,
       `x`.`color`             AS `color`,
       `p`.`L_name`            AS `L_name`,
       `p`.`F_name`            AS `F_name`,
       `e`.`id_company_pathon` AS `id_company_pathon`,
       `e`.`id_diakrisi`       AS `id_diakrisi`
from (((((`vletsiskostas_msc_diplomatiki`.`db_ekthesis` `e` left join `vletsiskostas_msc_diplomatiki`.`db_accident_place` `a` on (`e`.`id_accedent_place` = `a`.`id_accident_place`)) join `vletsiskostas_msc_diplomatiki`.`db_oximata` `o` on (`e`.`id_oximatos_pathon` = `o`.`id_oximata`)) join `vletsiskostas_msc_diplomatiki`.`db_person` `p` on (`e`.`id_pathon` = `p`.`id_person`)) join `vletsiskostas_msc_diplomatiki`.`db_markes` `m` on (`o`.`id_markes` = `m`.`id_markes`))
         join `vletsiskostas_msc_diplomatiki`.`db_xromata` `x` on (`o`.`id_xromata` = `x`.`id_xromata`))
where `e`.`Valid` = 'true';

