create definer = mscadmin@`%` view v_plir_timol_partner as
select `t`.`Ar_timologio_partner` AS `ar_timologio_partner`,
       `t`.`Date_timol`           AS `date_timol`,
       `t`.`id_partner`           AS `id_partner`,
       `t`.`id_grafeio`           AS `id_grafeio`,
       `t`.`Value`                AS `value`,
       `g`.`Name`                 AS `name`,
       `u`.`L_name`               AS `l_name`
from ((`vletsiskostas_msc_diplomatiki`.`db_pliromes_timologion_partner` `t` join `vletsiskostas_msc_diplomatiki`.`db_grafeio` `g` on (`t`.`id_grafeio` = `g`.`id_grafeio`))
         join `vletsiskostas_msc_diplomatiki`.`db_users` `u` on (`t`.`id_partner` = `u`.`id_users`))
where `t`.`Valid` = 'true';

-- comment on column v_plir_timol_partner.value not supported:  Αυτό αφαιρείται απο το υπόλοιπο του συνεργάτη.

