create definer = mscadmin@`%` view v_status_ekthesis_pano_apo3 as
select `e`.`id_ekthesis`     AS `id_ekthesis`,
       `e`.`Date_atiximatos` AS `date_atiximatos`,
       `p1`.`L_name`         AS `lname_ypait`,
       `o1`.`Ar_kyklo`       AS `ar_kyklo_yp`,
       `p`.`L_name`          AS `Lname_pathon`,
       `o`.`Ar_kyklo`        AS `ar_kyklo`,
       `u`.`user_name`       AS `user_name`,
       `e`.`Prot_bibliou`    AS `Prot_bibliou`,
       `c`.`comp_name`       AS `comp_name`
from (((((((`vletsiskostas_msc_diplomatiki`.`db_ekthesis` `e` join `vletsiskostas_msc_diplomatiki`.`db_person` `p` on (`e`.`id_pathon` = `p`.`id_person`)) join `vletsiskostas_msc_diplomatiki`.`db_oximata` `o` on (`e`.`id_oximatos_pathon` = `o`.`id_oximata`)) join `vletsiskostas_msc_diplomatiki`.`db_company` `c` on (`e`.`id_company_pathon` = `c`.`id_company`)) join `vletsiskostas_msc_diplomatiki`.`db_status_ekthesis` `s` on (`e`.`id_ekthesis` = `s`.`id_ekthesis`)) join `vletsiskostas_msc_diplomatiki`.`db_users` `u` on (`e`.`id_users` = `u`.`id_users`)) left join `vletsiskostas_msc_diplomatiki`.`db_person` `p1` on (`e`.`id_ypaitiou` = `p1`.`id_person`))
         left join `vletsiskostas_msc_diplomatiki`.`db_oximata` `o1` on (`e`.`id_oximatos_ypaitiou` = `o1`.`id_oximata`))
where `e`.`Valid` = 'true'
  and `s`.`Valid` = 'Íáé'
  and `s`.`id_status` >= 3;

