create definer = mscadmin@`%` view v_ekthesis_of_oximata as
select `e`.`id_ekthesis`        AS `id_ekthesis`,
       `e`.`Date_eksetasis`     AS `date_eksetasis`,
       `a`.`Place`              AS `place`,
       `c`.`comp_name`          AS `comp_name`,
       `e`.`id_oximatos_pathon` AS `id_oximatos_pathon`,
       `e`.`id_diakrisi`        AS `id_diakrisi`
from ((`vletsiskostas_msc_diplomatiki`.`db_ekthesis` `e` left join `vletsiskostas_msc_diplomatiki`.`db_accident_place` `a` on (`e`.`id_accedent_place` = `a`.`id_accident_place`))
         join `vletsiskostas_msc_diplomatiki`.`db_company` `c` on (`e`.`id_company_pathon` = `c`.`id_company`))
where `e`.`Valid` = 'true';

